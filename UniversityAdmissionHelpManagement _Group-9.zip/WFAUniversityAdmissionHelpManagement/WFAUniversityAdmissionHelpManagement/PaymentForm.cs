﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace WFAUniversityAdmissionHelpManagement

{
    public partial class PaymentForm : Form
    {
        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }
        private string Sql { get; set; }
        public PaymentForm()
        {
            InitializeComponent();
            this.Da = new DataAccess();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string sql = "select * from student";
            this.Ds = this.Da.ExecuteQuery(sql);
            int amount = 4000;
            int a= this.Ds.Tables[0].Rows.Count;
            this.txtFees.Text = (amount *a).ToString();   
            
        }
       
      
        private void btnUniInfo_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Form2 s = new Form2();
            s.Visible = true;
        }

        private void PaymentForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnNet_Click(object sender, EventArgs e)
        {
            string sql = "select * from student";
            this.Ds = this.Da.ExecuteQuery(sql);
            int amount = 4000;
            int a = this.Ds.Tables[0].Rows.Count;
            int b = amount * a;
            int result = b - Int32.Parse(txtSalary.Text);
            if (result > 0)
            {
                MessageBox.Show("Profit is made");
            }
            else
            {
                MessageBox.Show("Loss is made");

            }
        }
     

        
        

        
    }
}
